<?php

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	// echo "form is submitted";
	// exit();
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$country = $_POST['country'];
	$subject = $_POST['subject'];

	if ($firstname == "" || $lastname == "" || $country == "" || $subject == "") {
		$message = "Field must not be Empty !!!!";
	} else {
	$con = mysqli_connect('localhost','root','','alldata');
	$insert = $con->query("insert into students(firstname,lastname,country,subject) values('$firstname','$lastname','$country','$subject')");

	if ($insert) {
    $message = "Data inserted successfully";
  } else {
    $message = "Something went wrong";
  }
}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h3 style="">Contact Form</h3>

<div class="container">	
  	<a href="index.php" style="text-decoration: none;padding:5px 560px;color: blue;font-weight: bold;">View</a>
  <form action="" method="post">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
      <option selected="selected" disabled="disabled">Please Select Any One</option>
      <option value="Bangladesh">Bangladesh</option>
      <option value="India">India</option>
      <option value="Pakistan">Pakistan</option>
      <option value="Srilanka">Srilanka</option>
    </select>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:100px"></textarea>

    <!-- <input type="submit" class="submit" value="Submit"> -->
    <div class="row">
      <div class="col-md-3">
        <div class="main-button">
         <input type="submit" class="submit" value="Submit">
        </div>
      </div>
    </div>
  </form>
</div>

</body>
</html>
