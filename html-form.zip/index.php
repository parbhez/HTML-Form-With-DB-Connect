<?php
	$con = mysqli_connect('localhost','root','','alldata');
	$student = $con->query("select * from students order by student_id desc");
?>

<!DOCTYPE html>
<html>
<head>
	<title>All Stucdents Information</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-info">
		<div class="container mt-5 col-md-8">
			<div class="card">
				<div class="card-header">
					<h2>All Students Information</h2>
					<a href="form.php" class="btn btn-secondary">Add Info</a>
				</div>
				<div class="card-body">
					<table class="table table-borderd">
						<tr>
							<th>No</th>
							<th>Name</th>
							<th>Country</th>
							<th>Subject</th>
						</tr>
						<?php if($student):?>
						<?php	$i = 0; ?>
					<?php while($result = $student->fetch_object()) :?>
					<?php	$i++; ?>
						<tr>
							<td><?php echo $i;?></td>
							<td><?php echo $result->firstname.' '.$result->lastname;?></td>
							<td><?php echo $result->country;?></td>
							<td><?php echo $result->subject;?></td>
							
						</tr>
					<?php endwhile;?>
					<?php endif;?>
					</table>
				</div>
			</div>
		</div>
</body>
</html>